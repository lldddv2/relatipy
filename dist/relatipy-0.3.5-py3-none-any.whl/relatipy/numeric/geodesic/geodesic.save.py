"""
Timelike geodesic integration for test particles in a given spacetime metric.

This module defines :class:`Geodesic`, which casts the second-order geodesic
equation as a first-order eight-dimensional system and integrates it using
either :func:`scipy.integrate.solve_ivp` or the IAS15-based integrators in
``integrators``. When the optional C extension is available and the metric is
Kerr, a dedicated fast path is used.

The first-order system in proper time :math:`\\tau` is

.. math::

    \\frac{\\mathrm{d} x^\\sigma}{\\mathrm{d}\\tau} = u^\\sigma, \\qquad
    \\frac{\\mathrm{d} u^\\sigma}{\\mathrm{d}\\tau}
    = -\\Gamma^\\sigma_{\\mu\\nu}(x) \\, u^\\mu u^\\nu,

where :math:`\\Gamma^\\sigma_{\\mu\\nu}` are the Christoffel symbols provided by
the bound metric.

Notes
-----
The parameter name ``adaptative`` is retained for backward compatibility with
existing call sites (spelling mirrors the historical API).

Examples
--------
>>> import numpy as np
>>> from relatipy.numeric.geodesic import Geodesic
>>> from relatipy.numeric.metrics import Schwarzschild
>>> geo = Geodesic(Schwarzschild(5.972e24))
>>> y = np.zeros(8)
>>> geo.model_geodesic(0.0, y).shape
(8,)
"""

import numpy
from itertools import product
from scipy.integrate import solve_ivp

from ..coordinates import coordinate_systems
from .integrators.ias15_wrapper import ias15_integrate_geodesic

# Full-C Kerr backend (no Python callback during integration loop)
try:
    from .integrators.ias15_kerr_cffi import integrate_kerr_c as _integrate_kerr_c

    _KERR_C_BACKEND = True
except Exception:
    _KERR_C_BACKEND = False


class Geodesic:
    """
    Geodesic integrator bound to a :class:`~relatipy.numeric.metrics.base.BaseMetric`.

    Exposes the right-hand side of the first-order geodesic ODE and drivers that
    propagate an initial coordinate state through a list of proper times,
    optionally converting between coordinate charts supported by the metric.

    Parameters
    ----------
    metric : BaseMetric
        Spacetime metric providing Christoffel symbols, coordinate validation,
        and maps between coordinate objects and eight-dimensional state vectors.

    Attributes
    ----------
    metric : BaseMetric
        The metric instance passed at construction.
    valid_coordinate : str
        Name of the coordinate system in which the metric evaluates Christoffel
        symbols and state vectors (alias of ``metric.valid_coordinate``).

    Examples
    --------
    >>> from relatipy.numeric.geodesic import Geodesic
    >>> from relatipy.numeric.metrics import Schwarzschild
    >>> geo = Geodesic(Schwarzschild(5.972e24))
    >>> geo.valid_coordinate == geo.metric.valid_coordinate
    True
    """

    def __init__(self, metric):
        self.metric = metric
        self.valid_coordinate = self.metric.valid_coordinate

    def model_geodesic(self, tau, ys0):
        """
        Right-hand side of the first-order geodesic ODE in eight-dimensional form.

        Splits ``ys0`` into position :math:`x^\\mu` and four-velocity
        :math:`u^\\mu`, evaluates Christoffel symbols at :math:`x`, and returns
        the time derivatives :math:`(\\mathrm{d}x^\\mu/\\mathrm{d}\\tau,
        \\mathrm{d}u^\\mu/\\mathrm{d}\\tau)` with

        .. math::

            \\frac{\\mathrm{d} u^\\sigma}{\\mathrm{d}\\tau}
            = -\\Gamma^\\sigma_{\\mu\\nu}(x) \\, u^\\mu u^\\nu.

        Parameters
        ----------
        tau : float
            Proper time (affine parameter). Present for compatibility with ODE
            integrators; not used in the current implementation.
        ys0 : array_like of shape (8,)
            Stacked state :math:`[x^0, x^1, x^2, x^3, u^0, u^1, u^2, u^3]`.

        Returns
        -------
        ndarray of shape (8,)
            Concatenation ``[\\mathrm{d}x^\\mu/\\mathrm{d}\\tau,
            \\mathrm{d}u^\\mu/\\mathrm{d}\\tau]`` as a one-dimensional array.

        Examples
        --------
        >>> import numpy as np
        >>> from relatipy.numeric.geodesic import Geodesic
        >>> from relatipy.numeric.metrics import Schwarzschild
        >>> g = Geodesic(Schwarzschild(5.972e24))
        >>> y = np.zeros(8)
        >>> g.model_geodesic(0.0, y).shape
        (8,)
        """
        xs0 = ys0[:4]
        us0 = ys0[4:]

        as_ = numpy.zeros(4)

        chris = self.metric.get_christoffel_symbols(xs0)

        for sigma, mu, nu in product(range(4), repeat=3):
            as_[sigma] -= chris[sigma, mu, nu] * us0[mu] * us0[nu]

        return numpy.concatenate([us0, as_])

    def _estimate_dt_init(self, initial_conditions_orig, ys0):
        """
        Estimate a safe initial timestep for the IAS15 integrator.

        Tries, in order:

        #. If ``initial_conditions_orig`` is :class:`~relatipy.numeric.coordinates.orbital_elements.OrbitalElements`, use one twentieth of the Keplerian period :math:`P`.
        #. Else estimate from the initial proper acceleration magnitude:
           :math:`\\Delta\\tau \\sim 0.1 / \\sqrt{\\max |a|}` from
           :meth:`model_geodesic`.
        #. If both fail, return ``None`` so the caller applies its default
           (typically a fraction of the total span).

        Parameters
        ----------
        initial_conditions_orig : object
            Original coordinate object before conversion to
            :attr:`valid_coordinate`. Used to detect orbital elements and read an
            orbital period when available.
        ys0 : array_like of shape (8,)
            Initial eight-state used to evaluate :meth:`model_geodesic` for a
            dynamical-timescale estimate.

        Returns
        -------
        float or None
            Suggested initial timestep, or ``None`` if no heuristic applies.

        Examples
        --------
        ``_estimate_dt_init`` is internal to this module variant; the call below
        is skipped in doctest runs when the active ``Geodesic`` implementation
        does not define it.

        >>> import numpy as np
        >>> from relatipy.numeric.geodesic import Geodesic
        >>> from relatipy.numeric.metrics import Schwarzschild
        >>> g = Geodesic(Schwarzschild(5.972e24))
        >>> g._estimate_dt_init(None, np.zeros(8)) is None  # doctest: +SKIP
        True
        """
        # --- 1. OrbitalElements: use Keplerian period ---
        from ..coordinates.orbital_elements import OrbitalElements

        if isinstance(initial_conditions_orig, OrbitalElements):
            try:
                P = initial_conditions_orig._get_period()
                return P / 20.0
            except Exception:
                pass

        # --- 2. Dynamical timescale from initial acceleration ---
        try:
            a0 = self.model_geodesic(0.0, ys0)[4:]
            max_a = numpy.max(numpy.abs(a0))
            if max_a > 0:
                return 0.1 / numpy.sqrt(max_a)
        except Exception:
            pass

        return None  # caller will use default (tau_end - tau0) / 1000

    def get_path(self, initial_conditions, taus, integrator="Radau", adaptative=True):
        """
        Integrate the geodesic and return the trajectory in coordinate form.

        Converts ``initial_conditions`` to :attr:`valid_coordinate` if needed,
        builds the initial eight-state, calls the internal integrator, maps the
        result back to coordinate velocities, wraps the output in the
        appropriate coordinate class, and converts to the original chart if
        required.

        Parameters
        ----------
        initial_conditions : CoordinateBase
            Initial event and velocities in any coordinate system supported by the
            metric (see :obj:`~relatipy.numeric.coordinates.coordinate_systems`).
        taus : array_like
            Strictly increasing proper-time samples. Must contain at least two
            values (enforced in :meth:`_get_path_from_4state_vector`).
        integrator : str, optional
            Integration method. If ``"ias15"`` (case-insensitive), the IAS15 path
            is used; otherwise the string is passed as ``method`` to
            :func:`scipy.integrate.solve_ivp` (default ``"Radau"``).
        adaptative : bool, optional
            If True, the integrator chooses its own step sequence and dense output
            behavior; if False, the solution is evaluated (or interpolated) at
            the times in ``taus``.

        Returns
        -------
        CoordinateBase
            Coordinate object on the same chart as the input
            ``initial_conditions`` (after optional round-trip conversion), holding
            the integrated worldline.

        Examples
        --------
        >>> import numpy as np
        >>> from astropy import units as u
        >>> from relatipy.numeric.coordinates import Spherical
        >>> from relatipy.numeric.geodesic import Geodesic
        >>> from relatipy.numeric.metrics import Schwarzschild
        >>> M = 1.989e30 * u.kg
        >>> bh = Schwarzschild(M)
        >>> geo = Geodesic(bh)
        >>> r0 = 1.0e10 * bh.R_s
        >>> xs = np.array([0.0, r0, np.pi / 2, 0.0])
        >>> ic = Spherical(xs, vels=np.array([0.0, 0.0, 0.0]), from_dxs_dt=False)
        >>> taus = np.linspace(0.0, 1.0, 32)
        >>> path = geo.get_path(ic, taus, integrator="Radau", adaptative=False)
        >>> path.xs.shape == (4, len(taus))
        True
        """
        original_coordinate = initial_conditions.name_metric
        original_kwargs = initial_conditions.kwargs

        # Keep reference to original ICs before coordinate conversion (for dt_init)
        initial_conditions_orig = initial_conditions

        if initial_conditions.name_metric != self.valid_coordinate:
            initial_conditions = initial_conditions.convert_to(
                self.valid_coordinate, **self.metric.kwargs
            )

        ys0 = self.metric.get_4state_vector(initial_conditions)

        # Compute dt_init for IAS15 before calling the integrator
        dt_init_ias15 = self._estimate_dt_init(initial_conditions_orig, ys0)

        sol = self._get_path_from_4state_vector(
            ys0,
            taus,
            integrator=integrator,
            adaptative=adaptative,
            dt_init=dt_init_ias15,
        )

        dxs_dt = self.metric.get_dxs_dt_from_4velocity(sol[4:])
        ys = coordinate_systems[initial_conditions.name_metric](
            sol[:4], vels=dxs_dt[1:], from_dxs_dt=True, **initial_conditions.kwargs
        )

        if original_coordinate != initial_conditions.name_metric:
            ys = ys.convert_to(original_coordinate, **original_kwargs)

        return ys

    def _get_path_from_4state_vector(
        self, ys0, taus, integrator="Radau", adaptative=True, dt_init=None
    ):
        """
        Integrate the eight-state geodesic ODE from an initial state.

        Dispatches to IAS15 (optionally with the Kerr C backend) or to
        :func:`scipy.integrate.solve_ivp` depending on ``integrator``.

        Parameters
        ----------
        ys0 : array_like of shape (8,)
            Initial state :math:`[x^\\mu, u^\\mu]`.
        taus : array_like
            Monotonic proper-time grid; must contain at least two elements.
        integrator : str, optional
            Same convention as :meth:`get_path`.
        adaptative : bool, optional
            Same convention as :meth:`get_path`.
        dt_init : float or None, optional
            Initial step for IAS15. If ``None`` when using IAS15, a default
            fraction of the total span is applied, then capped relative to the
            span.

        Returns
        -------
        ndarray
            For SciPy integration, ``sol.y`` from :class:`scipy.integrate.OdeSolution`
            with shape ``(8, n)``. For IAS15 with ``adaptative=True``, an array of
            shape ``(8, n)`` whose columns are states at the integrator output
            times; with ``adaptative=False``, states interpolated to ``taus``.

        Raises
        ------
        ValueError
            If ``taus`` has fewer than two elements.

        Examples
        --------
        >>> import numpy as np
        >>> from relatipy.numeric.geodesic import Geodesic
        >>> from relatipy.numeric.metrics import Schwarzschild
        >>> g = Geodesic(Schwarzschild(5.972e24))
        >>> y0 = np.zeros(8)
        >>> taus = np.linspace(0.0, 1.0, 10)
        >>> out = g._get_path_from_4state_vector(y0, taus, integrator="Radau",
        ...     adaptative=False)
        >>> out.shape[0] == 8
        True
        """
        if len(taus) < 2:
            raise ValueError("taus must contain at least 2 values.")

        t_span = (taus[0], taus[-1])

        if integrator.lower() == "ias15":
            span = taus[-1] - taus[0]
            if dt_init is None:
                dt_init = span / 20.0
            dt_init = min(dt_init, span / 10.0)

            # Use the full-C Kerr backend when available (fastest path)
            from ..metrics.kerr_metric import Kerr as _KerrMetric

            if _KERR_C_BACKEND and isinstance(self.metric, _KerrMetric):
                tau_out, states = _integrate_kerr_c(
                    self.metric.R_s,
                    self.metric.a,
                    ys0,
                    taus[0],
                    taus[-1],
                    dt_init,
                    epsilon=1e-10,
                )
            else:
                # Generic path: Python callback to model_geodesic
                def accel_func(state8, tau):
                    return self.model_geodesic(tau, state8)[4:]

                tau_out, states = ias15_integrate_geodesic(
                    accel_func,
                    ys0,
                    taus[0],
                    taus[-1],
                    dt_init=dt_init,
                    epsilon=1e-6,
                    adaptive_output=adaptative,
                    tau_eval=None if adaptative else taus,
                )

            if not adaptative:
                # Interpolate to requested taus
                from scipy.interpolate import interp1d
                import numpy as np

                taus_np = numpy.asarray(taus)
                n_pts = len(tau_out)
                kind = "cubic" if n_pts >= 4 else "linear"
                out = numpy.zeros((8, len(taus_np)))
                for i in range(8):
                    f = interp1d(tau_out, states[:, i], kind=kind)
                    out[i] = f(taus_np)
                return out

            return states.T
        else:
            # Use scipy integrators
            if adaptative:
                sol = solve_ivp(self.model_geodesic, t_span, ys0, method=integrator)
            else:
                sol = solve_ivp(
                    self.model_geodesic, t_span, ys0, t_eval=taus, method=integrator
                )

            if sol.status == -1:
                print("WARNING: Integration failed.")

            return sol.y
